package com.blaupunkt.tsviewer;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class FisheyeGLView extends GLSurfaceView {

    public interface OnSurfaceReadyListener {
        void onSurfaceReady(Surface surface);
    }

    private final RendererImpl renderer;

    public FisheyeGLView(Context context) {
        super(context);
        setEGLContextClientVersion(2);
        renderer = new RendererImpl(context.getApplicationContext());
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
    }

    public void setOnSurfaceReadyListener(OnSurfaceReadyListener listener) {
        renderer.setSurfaceReadyCallback(listener);
    }

    public boolean isDewarpEnabled() {
        return renderer.dewarpEnabled;
    }

    public void setDewarpEnabled(boolean enabled) {
        renderer.dewarpEnabled = enabled;
        requestRender();
    }

    public void releaseSurface() {
        queueEvent(renderer::release);
    }

    private final class RendererImpl implements GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {
        private static final float[] FULL_QUAD = {
                -1f, -1f, 1f, -1f, -1f, 1f,
                 1f, -1f, 1f,  1f, -1f, 1f
        };

        private static final float[] TEX_QUAD = {
                0f, 1f, 1f, 1f, 0f, 0f,
                1f, 1f, 1f, 0f, 0f, 0f
        };

        private final Context context;
        private final FloatBuffer vertexBuffer = floatBuffer(FULL_QUAD);
        private final FloatBuffer texBuffer = floatBuffer(TEX_QUAD);
        private final float[] texMatrix = new float[16];

        private int program;
        private int positionHandle;
        private int texCoordHandle;
        private int texMatrixHandle;
        private int textureHandle;
        private int samplerHandle;
        private int dewarpHandle;

        private SurfaceTexture surfaceTexture;
        private Surface surface;
        private boolean frameAvailable;
        private boolean dewarpEnabled = true;
        private OnSurfaceReadyListener callback;

        RendererImpl(Context context) {
            this.context = context;
        }

        private FloatBuffer floatBuffer(float[] values) {
            FloatBuffer b = ByteBuffer.allocateDirect(values.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            b.put(values).position(0);
            return b;
        }

        void setSurfaceReadyCallback(OnSurfaceReadyListener callback) {
            this.callback = callback;
            if (surface != null) {
                callback.onSurfaceReady(surface);
            }
        }

        @Override
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            GLES20.glClearColor(0f, 0f, 0f, 1f);

            int[] textures = new int[1];
            GLES20.glGenTextures(1, textures, 0);
            textureHandle = textures[0];

            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureHandle);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);

            surfaceTexture = new SurfaceTexture(textureHandle);
            surfaceTexture.setOnFrameAvailableListener(this);
            surface = new Surface(surfaceTexture);

            String vertexSource = ShaderUtils.loadAsset(context, "shaders/vertex_shader.vert");
            String fragmentSource = ShaderUtils.loadAsset(context, "shaders/fisheye_dewarp.frag");
            program = ShaderUtils.createProgram(vertexSource, fragmentSource);

            positionHandle = GLES20.glGetAttribLocation(program, "aPosition");
            texCoordHandle = GLES20.glGetAttribLocation(program, "aTexCoords");
            texMatrixHandle = GLES20.glGetUniformLocation(program, "uTexMatrix");
            samplerHandle = GLES20.glGetUniformLocation(program, "uTexture");
            dewarpHandle = GLES20.glGetUniformLocation(program, "uStrength");

            if (callback != null) {
                callback.onSurfaceReady(surface);
            }
        }

        @Override
        public void onSurfaceChanged(GL10 gl, int width, int height) {
            GLES20.glViewport(0, 0, width, height);
        }

        @Override
        public void onDrawFrame(GL10 gl) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            if (surfaceTexture == null) return;

            synchronized (this) {
                if (frameAvailable) {
                    surfaceTexture.updateTexImage();
                    surfaceTexture.getTransformMatrix(texMatrix);
                    frameAvailable = false;
                }
            }

            GLES20.glUseProgram(program);

            vertexBuffer.position(0);
            GLES20.glEnableVertexAttribArray(positionHandle);
            GLES20.glVertexAttribPointer(positionHandle, 2, GLES20.GL_FLOAT, false, 0, vertexBuffer);

            texBuffer.position(0);
            GLES20.glEnableVertexAttribArray(texCoordHandle);
            GLES20.glVertexAttribPointer(texCoordHandle, 2, GLES20.GL_FLOAT, false, 0, texBuffer);

            GLES20.glUniformMatrix4fv(texMatrixHandle, 1, false, texMatrix);
            GLES20.glUniform1f(dewarpHandle, dewarpEnabled ? 0.45f : 0.0f);
            GLES20.glUniform1i(samplerHandle, 0);

            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureHandle);

            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);

            GLES20.glDisableVertexAttribArray(positionHandle);
            GLES20.glDisableVertexAttribArray(texCoordHandle);
        }

        @Override
        public synchronized void onFrameAvailable(SurfaceTexture surfaceTexture) {
            frameAvailable = true;
            FisheyeGLView.this.requestRender();
        }

        void release() {
            if (surface != null) {
                surface.release();
                surface = null;
            }
            if (surfaceTexture != null) {
                surfaceTexture.release();
                surfaceTexture = null;
            }
        }
    }
}
