package com.blaupunkt.tsviewer;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;

public class MainActivity extends AppCompatActivity {

    private static final int PICK_VIDEO = 1001;

    private ExoPlayer player;
    private FisheyeGLView glView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        glView = findViewById(R.id.gl_view);
        Button select = findViewById(R.id.select_button);
        Button play = findViewById(R.id.play_button);
        Button dewarp = findViewById(R.id.dewarp_button);

        player = new ExoPlayer.Builder(this).build();

        glView.setOnSurfaceReadyListener(surface -> player.setVideoSurface(surface));

        select.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, PICK_VIDEO);
        });

        play.setOnClickListener(v -> {
            if (player.getPlaybackState() == androidx.media3.common.Player.STATE_IDLE) {
                Toast.makeText(this, "Select a .TS video first", Toast.LENGTH_SHORT).show();
                return;
            }
            player.setPlayWhenReady(!player.getPlayWhenReady());
        });

        dewarp.setOnClickListener(v -> {
            boolean enabled = !glView.isDewarpEnabled();
            glView.setDewarpEnabled(enabled);
            dewarp.setText(enabled ? "Dewarp: ON" : "Dewarp: OFF");
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;

            try {
                getContentResolver().takePersistableUriPermission(
                        uri,
                        data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION
                );
            } catch (SecurityException ignored) {
            }

            player.setMediaItem(MediaItem.fromUri(uri));
            player.prepare();
            player.setPlayWhenReady(true);
        }
    }

    @Override
    protected void onDestroy() {
        if (player != null) {
            player.clearVideoSurface();
            player.release();
        }
        if (glView != null) {
            glView.releaseSurface();
        }
        super.onDestroy();
    }
}
