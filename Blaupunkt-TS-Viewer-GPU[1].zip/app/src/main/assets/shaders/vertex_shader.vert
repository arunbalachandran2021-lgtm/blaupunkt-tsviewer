attribute vec4 aPosition;
attribute vec2 aTexCoords;
uniform mat4 uTexMatrix;
varying vec2 vTexCoord;

void main() {
    gl_Position = aPosition;
    vec4 transformed = uTexMatrix * vec4(aTexCoords, 0.0, 1.0);
    vTexCoord = transformed.xy;
}
