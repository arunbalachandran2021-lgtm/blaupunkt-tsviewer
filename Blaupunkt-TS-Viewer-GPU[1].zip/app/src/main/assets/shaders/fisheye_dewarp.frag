#extension GL_OES_EGL_image_external : require
precision mediump float;

varying vec2 vTexCoord;
uniform samplerExternalOES uTexture;
uniform float uStrength;

void main() {
    vec2 p = vTexCoord * 2.0 - 1.0;
    float r = length(p);

    if (r < 0.0001) {
        gl_FragColor = texture2D(uTexture, vTexCoord);
        return;
    }

    float corrected = pow(r, 1.0 + uStrength);
    vec2 mapped = p * (corrected / r);
    vec2 uv = mapped * 0.5 + 0.5;

    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
        gl_FragColor = vec4(0.0);
    } else {
        gl_FragColor = texture2D(uTexture, uv);
    }
}
