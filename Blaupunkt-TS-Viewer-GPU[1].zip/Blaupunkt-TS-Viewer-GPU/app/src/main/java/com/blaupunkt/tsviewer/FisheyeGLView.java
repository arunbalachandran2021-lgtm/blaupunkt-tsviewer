package com.blaupunkt.tsviewer;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.view.Surface;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class FisheyeGLView extends GLSurfaceView {
    public interface SurfaceListener { void onVideoSurfaceAvailable(Surface surface); }

    private final Renderer renderer;

    public FisheyeGLView(Context context) {
        super(context);
        setEGLContextClientVersion(2);
        renderer = new Renderer(context);
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }

    public void setSurfaceListener(SurfaceListener listener) { renderer.listener = listener; }
    public void setDewarpEnabled(boolean enabled) { renderer.dewarpEnabled = enabled; }

    private static final class Renderer implements GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener {
        private final Context context;
        private final FloatBuffer vertices = makeBuffer(new float[]{-1,-1, 1,-1, -1,1, 1,1});
        private final FloatBuffer tex = makeBuffer(new float[]{0,1, 1,1, 0,0, 1,0});
        private int program;
        private int textureId;
        private SurfaceTexture surfaceTexture;
        private Surface surface;
        private int posLoc, texLoc, textureLoc, strengthLoc, aspectLoc, dewarpLoc;
        private float aspect = 1f;
        private boolean dewarpEnabled = true;
        private SurfaceListener listener;

        Renderer(Context context) { this.context = context.getApplicationContext(); }

        @Override public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            String v = readAsset("shaders/vertex_shader.vert");
            String f = readAsset("shaders/fisheye_dewarp.frag");
            int vs = ShaderUtils.compileShader(GLES20.GL_VERTEX_SHADER, v);
            int fs = ShaderUtils.compileShader(GLES20.GL_FRAGMENT_SHADER, f);
            program = ShaderUtils.linkProgram(vs, fs);
            GLES20.glDeleteShader(vs);
            GLES20.glDeleteShader(fs);

            posLoc = GLES20.glGetAttribLocation(program, "aPosition");
            texLoc = GLES20.glGetAttribLocation(program, "aTexCoords");
            textureLoc = GLES20.glGetUniformLocation(program, "uTexture");
            strengthLoc = GLES20.glGetUniformLocation(program, "uStrength");
            aspectLoc = GLES20.glGetUniformLocation(program, "uAspect");
            dewarpLoc = GLES20.glGetUniformLocation(program, "uDewarp");

            int[] ids = new int[1];
            GLES20.glGenTextures(1, ids, 0);
            textureId = ids[0];
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);

            surfaceTexture = new SurfaceTexture(textureId);
            surfaceTexture.setOnFrameAvailableListener(this);
            surface = new Surface(surfaceTexture);
            if (listener != null) listener.onVideoSurfaceAvailable(surface);
        }

        @Override public void onSurfaceChanged(GL10 gl, int width, int height) {
            GLES20.glViewport(0, 0, width, height);
            aspect = height == 0 ? 1f : (float) width / (float) height;
        }

        @Override public void onDrawFrame(GL10 gl) {
            if (surfaceTexture != null) {
                try { surfaceTexture.updateTexImage(); } catch (RuntimeException ignored) {}
            }
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
            GLES20.glUseProgram(program);
            vertices.position(0);
            tex.position(0);
            GLES20.glEnableVertexAttribArray(posLoc);
            GLES20.glVertexAttribPointer(posLoc, 2, GLES20.GL_FLOAT, false, 0, vertices);
            GLES20.glEnableVertexAttribArray(texLoc);
            GLES20.glVertexAttribPointer(texLoc, 2, GLES20.GL_FLOAT, false, 0, tex);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureId);
            GLES20.glUniform1i(textureLoc, 0);
            GLES20.glUniform1f(strengthLoc, 0.55f);
            GLES20.glUniform1f(aspectLoc, Math.max(0.5f, Math.min(2.0f, aspect)));
            GLES20.glUniform1f(dewarpLoc, dewarpEnabled ? 1f : 0f);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            GLES20.glDisableVertexAttribArray(posLoc);
            GLES20.glDisableVertexAttribArray(texLoc);
        }

        @Override public void onFrameAvailable(SurfaceTexture surfaceTexture) { /* continuous render mode */ }

        private String readAsset(String path) {
            try (InputStream in = context.getAssets().open(path);
                 BufferedReader br = new BufferedReader(new InputStreamReader(in))) {
                StringBuilder b = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) b.append(line).append('\n');
                return b.toString();
            } catch (Exception e) { throw new RuntimeException("Cannot read shader: " + path, e); }
        }

        private static FloatBuffer makeBuffer(float[] data) {
            ByteBuffer bb = ByteBuffer.allocateDirect(data.length * 4).order(ByteOrder.nativeOrder());
            FloatBuffer fb = bb.asFloatBuffer();
            fb.put(data).position(0);
            return fb;
        }
    }
}
