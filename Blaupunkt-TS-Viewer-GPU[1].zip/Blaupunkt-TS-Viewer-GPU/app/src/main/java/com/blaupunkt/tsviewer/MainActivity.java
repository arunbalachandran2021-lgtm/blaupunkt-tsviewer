package com.blaupunkt.tsviewer;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Surface;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;

public class MainActivity extends AppCompatActivity {
    private ExoPlayer player;
    private FisheyeGLView glView;
    private TextView status;
    private boolean dewarp = true;

    private final ActivityResultLauncher<String[]> picker = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(),
            uri -> {
                if (uri == null) return;
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
                play(uri);
            });

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        glView = findViewById(R.id.glView);
        status = findViewById(R.id.statusText);
        Button select = findViewById(R.id.selectButton);
        Button dewarpButton = findViewById(R.id.dewarpButton);

        player = new ExoPlayer.Builder(this).build();
        glView.setSurfaceListener(surface -> runOnUiThread(() -> player.setVideoSurface(surface)));
        select.setOnClickListener(v -> picker.launch(new String[]{"video/*", "video/mp2t", "*/*"}));
        dewarpButton.setOnClickListener(v -> {
            dewarp = !dewarp;
            glView.setDewarpEnabled(dewarp);
            dewarpButton.setText(dewarp ? "Dewarp: ON" : "Dewarp: OFF");
        });
    }

    private void play(Uri uri) {
        status.setText("Playing: " + uri.getLastPathSegment());
        player.setMediaItem(MediaItem.fromUri(uri));
        player.prepare();
        player.play();
    }

    @Override protected void onResume() { super.onResume(); glView.onResume(); }
    @Override protected void onPause() { glView.onPause(); super.onPause(); }
    @Override protected void onDestroy() {
        if (player != null) player.release();
        super.onDestroy();
    }
}
