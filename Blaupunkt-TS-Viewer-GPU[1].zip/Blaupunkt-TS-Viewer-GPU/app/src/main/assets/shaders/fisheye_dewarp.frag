#extension GL_OES_EGL_image_external : require
precision mediump float;

varying vec2 vTexCoord;
uniform samplerExternalOES uTexture;
uniform float uStrength;
uniform float uAspect;
uniform float uDewarp;

void main() {
    vec2 uv = vTexCoord;
    if (uDewarp < 0.5) {
        gl_FragColor = texture2D(uTexture, uv);
        return;
    }

    vec2 p = uv * 2.0 - 1.0;
    p.x *= uAspect;
    float r = length(p);
    if (r > 1.0) {
        gl_FragColor = vec4(0.0);
        return;
    }

    float k = 1.0 + uStrength * r * r;
    vec2 q = p / k;
    q.x /= uAspect;
    vec2 mapped = q * 0.5 + 0.5;

    if (mapped.x < 0.0 || mapped.x > 1.0 || mapped.y < 0.0 || mapped.y > 1.0) {
        gl_FragColor = vec4(0.0);
    } else {
        gl_FragColor = texture2D(uTexture, mapped);
    }
}
