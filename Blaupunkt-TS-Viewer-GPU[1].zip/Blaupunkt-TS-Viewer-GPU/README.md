# Blaupunkt TS Viewer — GPU Dewarp

Android app for selecting and playing Blaupunkt `.TS` recordings through an OpenGL ES 2.0 external-texture pipeline. The fisheye/dewarp shader is applied directly to the GPU video texture.

## Build in GitHub Codespaces

If the repository already has a Gradle installation, run:

```bash
gradle assembleDebug
```

APK:

`app/build/outputs/apk/debug/app-debug.apk`

The project also contains the Gradle wrapper. If wrapper files are present, `./gradlew assembleDebug` can be used instead.

## Notes

This is a first GPU pipeline intended to replace the earlier Media3 custom-effect attempt that produced a black screen. It uses `SurfaceTexture` + `GL_TEXTURE_EXTERNAL_OES` and an OES fragment shader, which is the correct texture type for a video SurfaceTexture.
