# Blaupunkt TS Viewer — GPU Dewarp

A clean replacement project for the current Blaupunkt TS Viewer experiment.

Architecture:
TS file -> Media3 ExoPlayer -> Surface -> SurfaceTexture -> OpenGL ES external OES texture
-> fisheye shader -> screen.

This version intentionally does NOT use Media3's custom `GlEffect` pipeline. Media3's
`GlShaderProgram` API processes OpenGL 2D textures; this direct SurfaceTexture approach
keeps the video texture as `GL_TEXTURE_EXTERNAL_OES`, which matches the shader.

## Build

Open this project in Android Studio or copy it into the Codespace.

Run:

    ./gradlew assembleDebug

If the Codespace already has a working Gradle wrapper/project setup, use that setup.

APK:

    app/build/outputs/apk/debug/app-debug.apk

## Test

1. Install the APK.
2. Press Select .TS.
3. Choose the Blaupunkt recording.
4. Video is sent directly to the GPU.
5. Dewarp can be toggled ON/OFF.

The current `uStrength` value is 0.45. It is only a starting calibration, not the final
Blaupunkt lens model. Once playback is confirmed, the dewarp mapping can be tuned to the
actual camera geometry.

## Important

This source project was generated here and has not been physically installed/tested on
the user's Android device in this response. The first test should be a build test in the
Codespace. If the build reports an API or Gradle-version mismatch, send the build output
and the project can be adjusted without editing shaders manually.
